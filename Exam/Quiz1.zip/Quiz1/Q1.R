library(MASS)
library(pracma)
library(matlib)

A<-matrix(1,nrow=15,ncol=15)
A
d<-diag(1,15,15)
d
A<-A+d
A

E<-eigenE$values
