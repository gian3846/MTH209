x=rgamma(1e6,shape=0.5,scale=0.7)
x
mean(x)
mean(sqrt(1+x^2))

A<-matrix(0,20,20)
B<-matrix(0,20,20)
for(n in 1:20)
{
for(i in 1:20)
{
  for(j in 1:20)
  {
    if(i==n||j==n)
    A[i,j]=n
  }
}
}


x<-rpois(100,log2)
x
mean(x)
log(2)/2
var(x)


x<-rnorm2d(1,rho=1)
