A<-matrix(c(1,2,1,0,3,1),ncol=2)
A

b<-c(16,9,8)

obj<-c(5,7)

library(gMOIP)
plotPolytope(
  A,
  b,
  obj,
  type = rep("c", ncol(A)),
  crit = "max",
  faces = rep("c", ncol(A)),
  plotFaces = TRUE,
  plotFeasible = TRUE,
  plotOptimum = TRUE,
  labels = "coord"
)
library(lpSolve)
Sol <- lp ("max", obj, A, c("<=","<=","<="), b)
Sol$objval
#A <- matrix(c(1, 1, 1, 7, -1, 1, -1, 0, 0, -1), nrow = 5, ncol = 2, byrow = TRUE)
#b <- c(7, 35, 3, 0, 0)
A <- matrix(c(1, 1, 1, 7, -1, 1), nrow = 3, ncol = 2, byrow = TRUE)
b <- c(7, 35, 3)

library(gMOIP)
plotPolytope(
  A,
  b,
  type = rep("c", ncol(A)),
  crit = "max",
  faces = rep("c", ncol(A)),
  plotFaces = TRUE,
  plotFeasible = TRUE,
  plotOptimum = FALSE,
  labels = "coord"
)

