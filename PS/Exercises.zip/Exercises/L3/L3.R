s <-seq(1,100,by=1)
k <-1/s
#k<-k[100]
A<-matrix(c(k,k^2,k^3,k^2,k^4,k^6,k^3,k^6,k^9),nrow=3,ncol=3)
det(A)
plot(det(A))
