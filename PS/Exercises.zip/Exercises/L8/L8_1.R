library(igraph)
library(igraphdata)
data("UKfaculty")
data<-UKfaculty
data
G <-induced_subgraph(
  data, vids=1:10
)
plot(G)

rom <- read.delim("https://slcladal.github.io/data/romeo_tidy.txt", sep = "\t")

G <-induced_subgraph(
  rom, vids=1:10
)
plot(G)
