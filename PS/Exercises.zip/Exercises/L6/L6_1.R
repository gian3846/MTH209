library(jpeg)
path = "C:/Users/Kumar Kanishk Singh/OneDrive - IIT Kanpur/IIT K/Semester 4/MTH209A/Exercises/L6"
setwd(path)

tour = readJPEG(paste(path,"paris_tourist.jpg", sep = "/"))
#no_tour = readJPEG(paste(path,"paris_no_tourist.jpg", sep = "/"))
new = readJPEG(paste(path,"rome.jpg", sep = "/"))
dim(tour); dim(no_tour); dim(new)

rtour = tour[, ,1]
gtour = tour[, ,2]
btour = tour[, ,3]
tour_rgb = list(rtour,gtour,btour)

prtour = prcomp(rtour, center = FALSE)
pgtour = prcomp(gtour, center = FALSE)
pbtour = prcomp(btour, center = FALSE)

tour.pca = list(prtour, pgtour, pbtour)

library(dplyr)

df = data.frame(scheme = rep(c("R", "G", "B"), each = 458), index = rep(1:458,  3), var = c(prtour$sdev^2, pgtour$sdev^2, pbtour$sdev^2))

df %<>% group_by(scheme) %>%
  mutate(propvar = 100*var/sum(var)) %>%
  mutate(cumsum = cumsum(propvar)) %>%
  ungroup()

# scree plot
library(ggplot2)
#relevel to make it look nicer
#df$scheme = factor(df$scheme,levels(df$scheme)[c(3,2,1)])

df %>% ggplot(aes(x = index, y = propvar, fill = scheme)) + 
  geom_bar(stat="identity") + 
  labs(title="Screeplot of Principal Component", x ="Principal Component", 
       y="% of Variance") + geom_line()  + 
  scale_x_continuous(limits = c(0,30)) +
  facet_wrap(~scheme)

df %>% ggplot(aes( x = index, y = cumsum, fill = scheme)) + 
  geom_bar(stat="identity") + 
  labs(title="Cumulative Proportion of Variance Explained Principal Component", x="Principal Component", 
       y="Cumulative % of Variance") + geom_line() + 
  scale_x_continuous(limits = c(0,30)) +
  facet_wrap(~scheme)

################################################################
# This is the number of desired PCs
#pcnum = c(2,30,200, 300)
pcnum = (1:5)*10

compress <- function(trained_rgb_pca, newrgb, pcnum, dims){
  r_rotate = trained_rgb_pca[[1]]$rotation
  g_rotate = trained_rgb_pca[[2]]$rotation
  b_rotate = trained_rgb_pca[[3]]$rotation
  
  r = newrgb[[1]]
  g = newrgb[[2]]
  b = newrgb[[3]]
  
  pred_r = (r %*% r_rotate)[,1:pcnum] %*% t(r_rotate[,1:pcnum])
  pred_g = (g %*% g_rotate)[,1:pcnum] %*% t(g_rotate[,1:pcnum])
  pred_b = (b %*% b_rotate)[,1:pcnum] %*% t(b_rotate[,1:pcnum])
  
  pred.pca = list(pred_r, pred_g, pred_b)
  pred.array = array(as.numeric(unlist(pred.pca)),dim = dims)
  return(pred.array)
}

for(i in pcnum){
  pca.img = compress(tour.pca, tour_rgb, pcnum = i, dims = c( 458, 715,3))
  writeJPEG(pca.img, paste('no_tourist_compressed_', 
                           round(i,0), '_components.jpg', sep = ''))
}

