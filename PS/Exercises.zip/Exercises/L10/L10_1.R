birthday<-function(n)
{
 ans<-1
 for(i in 1:n)
 {
    ans=ans*(365-i+1)/365
 }
 return(1-ans)
}

birthday(23)  

pbirthday(23)

