library(MASS)
library(pracma)

A<-matrix(c(3,1,2,-3,0,2,-2,-1,-2,-3,-1,-1,-1,-2,-3,-1,0,-2,3,-3,0,2,-3,0),nrow=4,ncol=6)
A

r<-orth(rref(A))
r

c<-orth(rref(t(A)))
c

Null(A)
