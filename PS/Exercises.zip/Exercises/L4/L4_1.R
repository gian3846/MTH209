library(rgl)
# Create some dummy data
dat <- replicate(2, 1:3)
# Initialize the scene, no data plotted
plot3d(dat, type = 'n', xlim = c(-1, 8), ylim = c(-1, 8), zlim = c(-10, 20), xlab = '', ylab = '', zlab = '')
# Define the linear plane
planes3d(1, 1, 1, 0, col = 'red', alpha = 0.6)
planes3d(2, 1, -1, 0, col = 'blue', alpha = 0.6)
planes3d(-3, 2, 5, 0, col = 'yellow', alpha = 0.6)
planes3d(1, -1, -1, 0, col = 'green', alpha = 0.6)
# Define the origin
points3d(x=0, y=0, z=0)



