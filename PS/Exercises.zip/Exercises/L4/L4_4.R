library(MASS)
library(pracma)

B<-matrix(c(0,1,1,1,1,1,0,1,1,1,1,1,0,1,1,1,1,1,0,1,1,1,1,1,0),nrow=5,ncol=5)
B

Binv<-inv(B)
Binv
v<-c(0,3,3,1,0)
v
v2<-Binv%*%v
v2





## Library for the Credit data set
library(ISLR)

## Libraries for Plotting our Results
library(ggplot2)
library(ggfortify)
library(gridExtra)

## for inv() function
library(pracma)

data(Auto)

Auto[1,]

x<-Auto[,-9]

pca <- princomp(x)
pca$loadings


T <- pca$loadings
D <- inv(T) %*% t(x)
y <- t(D)
plot(y)

library(e1071)

z <- svm(cylinders~., Auto[,c(2,3,4)])
print(z)
plot(z, Auto[,c(2,3,4)])

