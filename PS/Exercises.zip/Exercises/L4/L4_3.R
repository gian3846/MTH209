library(MASS)
library(pracma)

A<-matrix(c(-5,-7,1,5,-2,3,-1,-4,4),nrow=3,ncol=3)
A

b<-c(0,0,0)

B<-cbind(A,b)
B
rref(B)
Solve(B)

Null(t(A))
null(A)

rref(A) #row space

rref(t(A)) #col space

Rank(A)

dim(A)
