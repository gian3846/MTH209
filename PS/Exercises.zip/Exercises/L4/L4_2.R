library(matlib)
library(pracma)
library(MASS)

A<-matrix(c(1,-1,1,1,-2,-2,2,-1,2,1,3,2,-3,0,-2,1,4,-4,2,-1),ncol=5,nrow=4,byrow = T)
A
r<-rref(A)
b<-c(0,0,0,0)

t(rref(t(A)))

Null(t(A))
nullspace(A)
