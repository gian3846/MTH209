sheep<-read.table("Sheep.dat",header=T)
sheep
Living<-which(sheep$survival==1)
mean(sheep[Living,2])
Dead<-which(sheep$survival==0)
mean(sheep[Dead,2])
boxplot(sheep[Living,2])
boxplot(sheep[Dead,2])
