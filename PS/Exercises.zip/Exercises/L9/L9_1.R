data<-read.table("Carbon_West.dat", header=TRUE)
data
hist(data$CO2,xlab="CO2",ylab="Proportion",freq=FALSE)# histogram
