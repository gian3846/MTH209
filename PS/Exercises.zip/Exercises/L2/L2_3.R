library(magick)

inp_img <- image_read("http://polytopes.net/Tora_color.png")
image_info(inp_img)

plot(inp_img)

mod_img <- image_rotate(inp_img, degrees=180)
plot(mod_img)

mod_img <- image_flip(inp_img)
plot(mod_img)

mod_img <- image_flop(inp_img)
plot(mod_img)
