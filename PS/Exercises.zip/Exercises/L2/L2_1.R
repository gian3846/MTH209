library(mvtnorm)
library(ggplot2)
library(matlib)

## Standard deviation
sigma <- matrix(c(4,2,2,3), ncol = 2, nrow = 2) 

## Mean
mu <- c(0, 0)
n <- 1000
set.seed(123)
x <- rmvnorm(n = n, mean = mu, sigma = sigma)
d <- data.frame(x)
x

r<-matrix(c(1/sqrt(2),1/sqrt(2),-1/sqrt(2),1/sqrt(2)),nrow=2,ncol=2)

x2<-x%*%r
d2<-data.frame(x2)

p2 <- ggplot(d2, aes(x = X1, y = X2)) + geom_point(alpha = .5) + geom_density_2d()
p2

r3<-matrix(c(0,1,-1,0),nrow=2,ncol=2)

x3<-x%*%r3
d3<-data.frame(x3)
 
p3 <- ggplot(d3, aes(x = X1, y = X2)) + geom_point(alpha = .5) + geom_density_2d()
p3          

#y <- x - mu
y <- x - t(matrix(rep(mu,n), nrow=2))
E <- eigen(sigma)
E$vectors
y <- y %*% t(inv(E$vectors))
dd <- data.frame(y)
p4 <- ggplot(dd, aes(x = X1, y = X2)) + geom_point(alpha = .5) + geom_density_2d()
p4
